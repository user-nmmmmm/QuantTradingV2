# 数据覆盖与异常报告

60/60 币种已取得 Binance 日线，下载失败 0，内部缺失日期 0；输入拒绝重复时间、非有限值、非正价格和非法 OHLC。真实极端价格没有按收益删除。完整哈希及逐次请求 URL 见 data_manifest.json 和 data_inputs/*.source.json。

2016-01-01 至 2017-08-16 为 Binance 数据出现前的现金阶段。币种上市前不填造价格，指标按各币种实际历史预热。第一根真实 Binance bar 作为本次最早可参与时间的证据，没有宣称核实全部正式上市公告。静态选择 60 币种存在选择及幸存者偏差。

五个截断序列使用当时公开的保证金交易截止公告；从公告可见后阻止新增风险，在截止前最后完整日线收盘有成本退出。不是把历史文件最后一行当成免费下架成交。原始现货行情仍完整保存在输入目录。

|币种|保证金截止（UTC）|公告|
|---|---|---|
|MATIC/USDT|2024-09-05T11:00:00Z|[Binance 官方](https://www.binance.com/en/support/announcement/detail/6a6de383727f4659a3050f7982e1620f)|
|EOS/USDT|2025-05-21T10:00:00Z|[Binance 官方](https://www.binance.com/en/support/announcement/detail/1e89a9ca957c4b0ca7502e60b993e201)|
|XMR/USDT|2024-02-16T06:00:00Z|[Binance 官方](https://www.binance.com/en/support/announcement/detail/f73b083ba6834771b07dbe5319917ae5)|
|FTM/USDT|2025-01-08T06:00:00Z|[Binance 官方](https://www.binance.com/en/support/announcement/detail/aec6fcbc84b749eeab6690e6bcac2f3d)|
|MKR/USDT|2025-09-08T10:00:00Z|[Binance 官方](https://www.binance.com/en/support/announcement/detail/bf29506a33a94c17a5d5a01e74e646d2)|

历史保证金资格、额度和逐日利率并未完全核实，尤其不能将 2017 年起的 spot_margin 模型解释为当时已提供同等保证金产品。8% 借款利率及默认额度是固定模型假设；不是经考证的历史借贷重建。日线成交时间沿用 bar 标签，预定下架按该日线收盘执行。
