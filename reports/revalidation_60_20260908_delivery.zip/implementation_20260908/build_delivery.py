"""Presentation-only completion: frozen simulation outputs are not changed."""
from pathlib import Path
import json
import sys
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from core.reproducibility import sha256_file
from scripts.run_revalidation60 import source_hashes, save

p = ROOT / "reports/revalidation_60_20260908"
frozen = json.loads((p / "frozen_protocol.json").read_text())
assert source_hashes() == frozen["source_hashes"], "Code changed after freeze"
final_test_log = ROOT / "reports/implementation_20260908/final_full_coverage.txt"
assert "709 passed, 1 skipped" in final_test_log.read_text(encoding="utf-8", errors="replace")
save(p / "engineering_final_verification.json", {"passed": True, "pytest_passed": 709, "skipped": 1,
     "subtests_passed": 46, "warnings": 2, "coverage_pct": 86.19, "source_hashes": source_hashes(),
     "test_log_sha256": sha256_file(final_test_log), "original_pre_run_gate": "engineering_gate.json"})
summaries = json.loads((p / "all_run_summaries.json").read_text())
lookup = {row["name"]: row for row in summaries}
assert len(summaries) == 22
main = lookup["main_1"]
metrics = json.loads((p / "runs/main_1/metrics.json").read_text())
periods = json.loads((p / "runs/main_1/period_metrics.json").read_text())
cohorts = json.loads((p / "cohort_concentration.json").read_text())
gates = json.loads((p / "research_gates.json").read_text())
trades = pd.read_csv(p / "runs/main_1/trades.csv")
curves = {}
phase_records = []
for row in summaries:
    name = row["name"]
    curve = pd.read_csv(p / f"runs/{name}/equity_requested_period.csv", index_col="timestamp", parse_dates=True)
    curve["operating_phase"] = curve.phase
    # Existing engine lifecycle status can be completed while the strategy is
    # manually locked. Label that explicitly using its immutable transitions.
    for transition in row["lifecycle"].get("health_transition_log", []):
        if transition["strategy"] == "TrendBreakout" and transition["to"] == "manual_lock":
            at = pd.Timestamp(transition["at"]).tz_localize(None)
            mask = curve.index >= at
            curve.loc[mask, "operating_phase"] = "strategy_health_manual_lock_exit_only"
            curve.loc[mask & (curve.gross_exposure.abs() < 1e-9), "operating_phase"] = "strategy_health_manual_lock_cash"
            phase_records.append({"run": name, "manual_lock_at": at, "reason": transition["reason"]})
    curve.to_csv(p / f"runs/{name}/equity_with_operating_phase.csv", index_label="timestamp")
    curves[name] = curve
    identity = json.loads((p / f"runs/{name}/accounting_check.json").read_text())
    assert identity["ok"] and identity["discrepancy_count"] == 0
    assert curve.index[-1].date() == pd.Timestamp(row["end"]).date()
    ledger_path = p / f"runs/{name}/financing_ledger.csv"
    try:
        financing = pd.read_csv(ledger_path)
        entries = len(financing)
    except pd.errors.EmptyDataError:
        entries = 0
    save(p / f"runs/{name}/financing_summary.json", {"entries": entries,
         "annual_borrow_rate": 0.08 * row["cost_multiplier"], "interpretation": "No accrual entries means no financed balance was charged; not evidence of free borrowing"})
save(p / "operating_phases.json", phase_records)
inventory = json.loads((p / "data_manifest.json").read_text())
coverage = []
for symbol in frozen["symbols"]:
    row = inventory["symbols"][symbol]
    coverage.append({"symbol": symbol, "rows": row["rows"], "first": row["first"], "last_raw": row["last"],
         "missing_days": row["missing_internal_days"], "sha256": row["sha256"], "source": row["source"],
         "margin_cutoff": (row.get("delisting_evidence") or {}).get("margin_cutoff"),
         "announcement": (row.get("delisting_evidence") or {}).get("url")})
pd.DataFrame(coverage).to_csv(p / "data_coverage.csv", index=False)
data_text = "# 数据覆盖与异常报告\n\n60/60 币种已取得 Binance 日线，下载失败 0，内部缺失日期 0；输入拒绝重复时间、非有限值、非正价格和非法 OHLC。真实极端价格没有按收益删除。完整哈希及逐次请求 URL 见 data_manifest.json 和 data_inputs/*.source.json。\n\n"
data_text += "2016-01-01 至 2017-08-16 为 Binance 数据出现前的现金阶段。币种上市前不填造价格，指标按各币种实际历史预热。第一根真实 Binance bar 作为本次最早可参与时间的证据，没有宣称核实全部正式上市公告。静态选择 60 币种存在选择及幸存者偏差。\n\n"
data_text += "五个截断序列使用当时公开的保证金交易截止公告；从公告可见后阻止新增风险，在截止前最后完整日线收盘有成本退出。不是把历史文件最后一行当成免费下架成交。原始现货行情仍完整保存在输入目录。\n\n|币种|保证金截止（UTC）|公告|\n|---|---|---|\n"
for row in coverage:
    if row["margin_cutoff"]:
        data_text += f"|{row['symbol']}|{row['margin_cutoff']}|[Binance 官方]({row['announcement']})|\n"
data_text += "\n历史保证金资格、额度和逐日利率并未完全核实，尤其不能将 2017 年起的 spot_margin 模型解释为当时已提供同等保证金产品。8% 借款利率及默认额度是固定模型假设；不是经考证的历史借贷重建。日线成交时间沿用 bar 标签，预定下架按该日线收盘执行。\n"
(p / "data_quality_report.md").write_text(data_text, encoding="utf-8")
curve = curves["main_1"]
fig, axes = plt.subplots(2, 1, figsize=(13, 8), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
axes[0].plot(curve.index, curve.equity, label="TrendBreakout modeled net equity")
axes[0].axhline(10000, color="gray", linestyle="--", label="Initial capital / cash")
axes[1].fill_between(curve.index, (curve.equity / curve.equity.cummax() - 1) * 100, 0, alpha=.3)
lock, flat = pd.Timestamp("2022-08-20"), pd.Timestamp("2022-09-20")
for ax in axes:
    ax.axvline(lock, color="firebrick", linestyle=":")
    ax.axvspan(flat, curve.index[-1], color="gray", alpha=.17)
    ax.grid(alpha=.2)
axes[0].text(pd.Timestamp("2023-01-01"), 18000, "Strategy health MANUAL_LOCK\nCash after final exit on 2022-09-19", color="firebrick")
axes[0].set_ylabel("USDT")
axes[1].set_ylabel("Drawdown %")
axes[0].legend(loc="upper left")
fig.suptitle("60-coin fixed-parameter backtest | Trading ended long before requested end")
fig.tight_layout()
fig.savefig(p / "strategy_equity_operating_phases.png", dpi=160)
plt.close(fig)
rolling = [r for r in summaries if r["name"].startswith("rolling")]
lines = ["# 60 币种固定参数回测与 P0–P2 修复报告", "",
"工程修复已落地并通过本轮离线验收，60/60 数据准备及 22 次预定引擎运行已完成。研究准入未通过，继续 `paused_revalidation`。没有启动真实交易，也没有修改策略参数寻求更好收益。", "",
"## 主结果与活动期间", "",
f"本金 10,000 USDT，2016-01-01 至 2026-06-30（含结束日，UTC），Binance 日线，固定 60 币种，spot_margin。期末权益 **{main['final_equity']:,.2f} USDT**，总收益 **{main['return_pct']:.2f}%**，最大回撤 **{main['max_drawdown_pct']:.2f}%**。", "",
f"纳入 60 个币种，实际产生交易 {trades.symbol.nunique()} 个；未交易币种没有被剔除。{len(trades)} 笔成交、{int(metrics['TotalTrades'])} 个完整往返交易、{main['closed_event_count']} 个 lot 平仓事件。PF {metrics['ProfitFactor']:.3f}，胜率 {metrics['WinRate']:.2%}，平均盈利 {metrics['AvgWin']:.2f} USDT，平均亏损 {metrics['AvgLoss']:.2f} USDT，平均盈亏比 {metrics['AvgWin']/abs(metrics['AvgLoss']):.3f}。", "",
"**策略在 2022-08-20 进入健康 MANUAL_LOCK，停止新增风险；最后一笔退出为 2022-09-19，其后持有现金。** 整段结束不等于策略持续正常交易至 2026 年。主回测没有触发组合终止清算；这里是策略健康锁定，与 validation20 的组合清算停机不同。带运行阶段标注的曲线另存 `equity_with_operating_phase.csv`，保留原引擎输出。", "",
f"![策略权益与停机阶段]({(p / 'strategy_equity_operating_phases.png').as_posix()})", "",
"|统计范围|CAGR|Sharpe|Sortino|平均总敞口/权益|换手（成交额/期间均值权益）|", "|---|---:|---:|---:|---:|---:|"]
for label, key in [("完整请求期间 2016-01-01—2026-06-30", "requested"), ("有效市场期间 2017-08-17—2026-06-30", "market"), ("实际交易期间 2017-11-17—2022-09-19", "active")]:
    m = periods[key]
    lines.append(f"|{label}|{m['CAGR']:.2%}|{m['SharpeRatio']:.3f}|{m['SortinoRatio']:.3f}|{m['MeanGrossExposure']:.2%}|{m['Turnover']:.3f}|")
lines += ["", "最大回撤从 2021-04-16 高点开始，到 2022-09-19 达到谷底，至请求结束未恢复。主回测最大总敞口约 74.94%，融资账本没有计费条目，实际融资费用为 0；8% 年化模型已配置，但这个主路径没有产生收费借款余额。因此融资压力缺乏非零融资场景的研究证据。", "",
"## 分段、滚动和压力测试", "", "|运行|范围|期末权益 USDT|收益|最大回撤|", "|---|---|---:|---:|---:|"]
for name in ["train60", "validation20", "final20", "cost_1.5", "cost_2", "cost_3", "end_exit_sensitivity"]:
    r = lookup[name]
    lines.append(f"|{name}|{str(r['start'])[:10]}—{str(r['end'])[:10]}|{r['final_equity']:,.2f}|{r['return_pct']:.2f}%|{r['max_drawdown_pct']:.2f}%|")
lines += ["", "validation20 在 **2024-03-19** 触发组合清算并停止，之后是风险停机现金阶段；最大回撤 20.47% 超过门槛，保留真实成本导致的越限。期末有成本退出敏感性与主结果相同，因为 2026-06-30 已无持仓；这不是免除退出成本。", "",
f"滚动测试使用 730/180/180 bar、purge 30、embargo 30，固定参数不拟合，每个测试窗独立引擎及 10,000 USDT，提供 100 根前置 bar 预热，并在窗口末有成本退出。11 窗中 {sum(r['return_pct']>0 for r in rolling)} 窗盈利、{sum(r['return_pct']<=0 for r in rolling)} 窗非盈利，中位收益 {np.median([r['return_pct'] for r in rolling]):.2f}%。训练/验证时段只定义滚动时间结构，不进行参数估计。完整窗口结果在 all_run_summaries.json。", "",
"三次主回测使用独立引擎及策略状态、固定随机种子，交易、权益、基准和审计摘要哈希全部一致；耗时和文件生成时间未纳入。成本 1/1.5/2/3 是重新执行引擎，乘数覆盖手续费、价差、滑点、波动滑点、冲击、融资和清算罚金，不是事后从原利润扣减。", "",
"## 收益集中度与准入结论", "",
"使用开仓策略、UTC 退出日、退出控制器和风险动作身份组成 cohort。主回测有 78 个 cohort；连续 5-cohort 循环块 bootstrap，seed 42、2,000 次，EndOfBacktest 账面收尾事件不进入 cohort。", "",
"|移除盈利 cohort 数|剩余净平仓盈亏 USDT|95% 盈亏区间|cohort PF|95% PF 区间|", "|---:|---:|---|---:|---|"]
for n in (0, 5, 10):
    s = cohorts['scenarios'][str(n)]
    lines.append(f"|{n}|{s['remaining_net_closed_pnl']:,.2f}|{s['pnl_95pct_ci'][0]:,.2f} 至 {s['pnl_95pct_ci'][1]:,.2f}|{s['profit_factor']:.3f}|{s['pf_95pct_ci'][0]:.3f} 至 {s['pf_95pct_ci'][1]:.3f}|")
lines += ["", "cohort 移除是收益归属敏感性，未把删除后的成交当成可执行反事实组合。主回测 PF 门槛和 1.5 倍成本门槛通过，但移除前 10 个盈利 cohort 后转亏，集中度门槛失败。最后 20% 仅有 **20 个独立 cohort**，不足 30 个样本门槛，PF 显著性与集中度判定均为证据不足。分段验证表现不稳定，也已经出现组合清算。", "",
"同期现金期末为 10,000 USDT；BTC/ETH 各 50%、各自首次可交易日开盘买入并持有的毛收益参考，期末约 94,886.30 USDT（+848.86%）。该基准不计交易成本、不融资、不再平衡，不能将其与本策略风险强度视为相同。主回测没有超过该基准；final20 则跑赢该窗口下跌的基准，但不能弥补统计样本不足。", "",
"2016 现金段不参与 60/20/20 分段配额。最后 20% 在最终经济配置固定后执行一次预定评估，没有用于选参；早期两次集成尝试仅发生在 2017—2018 的导出流程，没有运行 holdout。这是回顾性历史验证，不声称历史数据完全未被观察。未做参数优化、因子选优及跨交易所验证。", "",
"## 工程验收与交付边界", "",
"冻结前完整 pytest 为 708 passed；最终完整交付复核为 **709 passed、1 skipped、46 subtests passed，覆盖率 86.19% / 门槛 55%**。导出器 4 项专项回归、lint、关键 mypy、环境与锁文件验证通过。完整测试出现 2 条 SQLite ResourceWarning，未当作测试失败，也不将其隐藏。跳过项为需要真实交易所环境的 E2E。新交易联调使用有状态离线交易所、真实 SafeLiveBroker、边界、订单库、风险预算和持仓投影，不仅是固定 accepted 替身。22 次正式运行会计核对全部通过，没有不平差。rolling_06 另有 15 条真实模型融资计提，融资计算通路产生了可核对账本；主回测和主路径成本压力均无融资余额，不把零费用当成借贷压力通过。", "",
"P0–P2 验收表见 ../implementation_20260908/p0_p2_acceptance.md；迁移恢复说明见 ../../docs/revalidation_migration_recovery_20260908.md。真实账户条件单资格、真实网络恢复、历史保证金资格/额度/利率以及跨库原子快照仍没有完整验证。身份不明旧库不会自动迁入，缺少归属/止损/真实成交事实保持恢复状态。", "",
"数据覆盖、五个保证金截止公告及模型限制见 data_quality_report.md。逐币首末时间、缺口和校验和在 data_coverage.csv，原始公共来源 URL 在 data_manifest.json。冻结源码和配置在 frozen_source.zip / frozen_protocol.json，输入逐文件 SHA-256 在 manifest；两个失败的导出尝试及其原冻结版本留在工作目录供追溯，不计入 22 次正式运行。", "",
"每个 runs/<name>/ 包含权益、成交、往返交易、CloseEvent、订单/止损/分配/风险审计、融资账本、分年结果、统计口径及会计恒等式检查。空融资 CSV 表示该路径无融资条目，旁边 financing_summary.json 明确解释。", "",
"**结论：工程修复完成本轮离线验收，数据和回测执行完成，研究验证未通过。继续暂停策略；本次结果不能构成真实资金上线许可。**", ""]
(p / "README_zh.md").write_text("\n".join(lines), encoding="utf-8")
save(p / "completion_status.json", {"engineering": "implemented_offline_acceptance_passed", "data": "60_of_60_ready_with_disclosed_model_assumptions",
     "backtest": "22_runs_completed", "research_validation": "failed_and_partial_evidence_insufficient", "admission": "paused_revalidation",
     "real_trading_started": False, "configuration_tuned": False, "source_hashes_match": True,
     "final_pytest": {"passed": 709, "skipped": 1, "coverage_pct": 86.19},
     "presentation_script_sha256": sha256_file(__file__)})
artifacts = {q.relative_to(p).as_posix(): sha256_file(q) for q in p.rglob("*") if q.is_file()
             and ".incomplete." not in str(q) and ".before_" not in q.name and q.name not in {"artifact_manifest.json", "delivery.zip"}}
save(p / "artifact_manifest.json", artifacts)
archive_path = ROOT / "reports/revalidation_60_20260908_delivery.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for name in [*artifacts, "artifact_manifest.json"]:
        archive.write(p / name, f"revalidation_60_20260908/{name}")
    for q in (ROOT / "reports/implementation_20260908").glob("*"):
        if q.is_file() and q.suffix in {".md", ".txt", ".py"}:
            archive.write(q, f"implementation_20260908/{q.name}")
    archive.write(ROOT / "docs/revalidation_migration_recovery_20260908.md", "docs/revalidation_migration_recovery_20260908.md")
print("Delivery complete", archive_path, archive_path.stat().st_size)
