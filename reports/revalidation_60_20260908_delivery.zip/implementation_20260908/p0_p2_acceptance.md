# P0–P2 工程验收记录

对应 `reports/strategy_security_review_20260908.md`；源码以新回测包的 `frozen_protocol.json/source_hashes` 为准。此表描述工程修复及离线证据，不表示真实交易所验收或实盘准入。

| 原审查项 | 实现与可验收行为 | 证据 |
|---|---|---|
| P0 保护单接口和拒单 | 规范意图分离委托价、参考价、触发价；Binance/CCXT 能力及市场订单类型均核验；未确认保护失败关闭新增风险，拒单触发具名减仓 | `test_revalidation_execution.py`、`test_sr2_protective_orders.py` |
| P0 风险动作未落实 | 共享风险动作规划；REDUCE、日亏损、LIQUIDATE、LOCKED 提交实际减仓，保存目标与身份，核对残余；BLOCK_NEW 撤销开仓 | `test_revalidation_execution.py`、`test_revalidation_recovery.py`、`test_r7_fault_injection.py`、回测风险审计 |
| P0 成交归属缺失 | 从持久化真实成交重放 lot、初始风险、CloseEvent；成交 ID 增加订单作用域；重复成交去重；不重复应用账户现金流 | `test_revalidation_execution.py`、`test_g2_live_orders.py` |
| P1 紧急退出参考价 | 市价退出使用 reference_price；GapRiskResize 先处理竞争保护单再按实际持仓缩减，未达目标不记完成 | 有状态假交易所联调及 SR2 回归 |
| P1 保护替换身份和状态 | 每个动作持久化 sequence，同动作重试复用，替换产生新 ID；部分成交、撤单不明不认定已保护；正常退出与止损竞争核验余额 | 有状态假交易所部分成交、同 bar 替换、撤单超时、风险单部分成交重试测试 |
| P1 行情场所绑定 | 官方实盘路径固定 broker 交易所；显式交易所请求失败不回退 Yahoo/其他交易所；合约请求校验 contract 市场 | `test_data_fetcher.py`、`test_p6_live.py`；当前保证金采用 Binance 现货标的日线 |
| P1 账户模式传递 | 官方 Portfolio 使用配置账户模式；保证金解析资产、借款和利息净额，区分合约；第三币手续费缺失换算事实时阻止新增风险 | `test_revalidation_execution.py`、已有账户会计测试；回测 accounting_check/financing_ledger |
| P1 UNKNOWN 风险释放 | 普通 None/暂时不存在/不支持/列表不完整不能触发 TTL 风险释放；须权威证据或有审计身份的人工确认 | `test_p0_blockers.py`、`test_g2_live_orders.py`、`test_revalidation_recovery.py` |
| P2 同时点批量分配 | 收集同 close_time 候选后统一分配；会话风险从状态和订单事实恢复；跨进程日风险写入 BEGIN IMMEDIATE | 既有分配/预算/重启测试及完整 pytest；新回测 allocation_audit |
| P2 实时风险估值 | 日线只产生信号；实盘 ticker 含来源/时间/过期时间，失效阻止新增风险并保留保护核验通路 | 实盘 tick 故障测试；当前未对真实交易所延迟作验收 |
| P2 日志与事件解码 | 代理 URL 仅保留安全 authority；日志异常及公共告警直接出口递归脱敏；解码显式类型注册表；拒绝非有限配置/价格/数量 | `test_revalidation_security.py`、`test_revalidation_recovery.py`；仅虚构凭据 |
| P2 隔离、迁移和恢复 | 交易所/环境/账户/市场作用域；schema 2 增量迁移先备份；身份不明旧库拒绝自动认领；快照核验完整性/版本/身份 | `test_revalidation_recovery.py`；`docs/revalidation_migration_recovery_20260908.md` |

## 验收范围与限制

工程测试必须通过后才生成 `engineering_gate.json`，该文件记录测试日志 SHA-256 和冻结源码哈希；研究运行器检查其与当前源码一致。完整测试、lint、关键 mypy、环境和 lock 校验日志保存在本目录。受 Windows 沙箱临时目录权限限制，SQLite 离线测试使用经自动审批的沙箱外执行，不接触真实交易。

真实 Binance 账户条件单资格、真实网络超时恢复、历史逐币保证金资格/借贷额度/利率没有完整证据；交易所 sandbox E2E 保持未授权跳过。现货保证金没有合约撮合层 reduceOnly 保证，因此仍需独占账户及交易所事实核验。不能从本表推导真实资金已安全放行。

存在恢复问题的老订单不补造归属、初始止损或手续费事实。成交累计估计行保留为审计材料，但不冒充已核验成交计入归属；后续真实成交提供完整事实后才解除相应恢复问题。

代码修复、数据准备、回测执行和研究准入分别记录。研究结论见新 60 币种回测报告，策略必须继续 `paused_revalidation`。
