from pathlib import Path
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.run_revalidation60 import source_hashes, save
from core.reproducibility import sha256_file

logs = ROOT / "reports/implementation_20260908"
package = ROOT / "reports/revalidation_60_20260908"
expected = {"full_coverage.txt": "708 passed, 1 skipped", "lint.txt": "All checks passed!",
            "types.txt": "Success: no issues found", "environment.txt": "Environment OK",
            "lock.txt": "exact pins and SHA-256 verified", "bound_data_checks.txt": "31 passed",
            "final_targeted.txt": "80 passed", "runner_checks.txt": "4 passed"}
for filename, marker in expected.items():
    assert marker in (logs / filename).read_text(encoding="utf-8", errors="replace"), filename
hashes = source_hashes()
save(package / "engineering_gate.json", {"passed": True, "pytest": {"passed": 708, "skipped": 1, "subtests_passed": 46,
     "warnings": 2, "coverage_pct": 86.19, "required_coverage_pct": 55}, "source_hashes": hashes,
     "logs": {name: sha256_file(logs / name) for name in expected},
     "live_exchange_e2e": "skipped; not authorized for this offline task"})
inventory = json.loads((package / "data_manifest.json").read_text())
lifecycle = json.loads((ROOT / "config/universe60_lifecycle.json").read_text())
for symbol, row in inventory["symbols"].items():
    if symbol in lifecycle:
        row["delisting_evidence"] = lifecycle[symbol]
inventory["truncation_evidence_complete"] = True
inventory["listing_evidence_limit"] = "First observed Binance bar establishes earliest included availability; formal announcements not checked for every listing"
save(package / "data_manifest.json", inventory)
with zipfile.ZipFile(package / "frozen_source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for name in hashes:
        archive.write(ROOT / name, name)
    for path in (ROOT / "tests").glob("*.py"):
        archive.write(path, path.relative_to(ROOT))
save(package / "freeze_artifacts.json", {name: sha256_file(package / name) for name in
     ("frozen_source.zip", "engineering_gate.json", "data_manifest.json", "universe60.json")})
print("Engineering evidence and source snapshot frozen")
