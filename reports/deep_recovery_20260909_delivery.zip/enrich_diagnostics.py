"""Read-only engine-output analysis; writes only this report package."""
import ast
import json
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent
repo = root.parents[1]


def csv(name, file):
    try:
        return pd.read_csv(root / 'runs' / name / file)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


protocol = json.loads((root / 'frozen_protocol.json').read_text())
summaries = json.loads((root / 'all_run_summaries.json').read_text())
equity = csv('main_1', 'equity_engine.csv').set_index('timestamp')
trades = csv('main_1', 'trades.csv')
events = csv('main_1', 'close_events.csv')
cohorts = csv('main_1', 'strategy_health_cohorts.csv')
risks = csv('main_1', 'risk_budget_reconciliation.csv')
restoration = cohorts[(cohorts.exit_session >= '2023-07-21') & (cohorts.exit_session <= '2023-12-22')]
late = trades[pd.to_datetime(trades.fill_time) > '2022-09-19']
costs = [ast.literal_eval(value) for value in late.costs]
new_risks = risks[(risks.timestamp >= '2023-12-22') & (risks.timestamp <= '2023-12-26')]
peak = equity.equity.cummax().loc['2023-12-22']
restoration_equity = equity.loc['2023-12-22', 'equity']
rolling = [row for row in summaries if row['name'].startswith('rolling_')]
ret = np.array([row['return_pct'] for row in rolling])
counts = {}
for row in summaries:
    counts[row['name']] = len(csv(row['name'], 'financing_ledger.csv'))
checks = {}
for name in ('main_1', 'missing_one_percent', 'market_outage_7d'):
    rng = np.random.default_rng(42)
    available = {}
    for symbol in protocol['symbols']:
        entry = protocol['data_manifest']['symbols'][symbol]
        frame = pd.read_csv(repo / 'reports/revalidation_60_20260908/data_inputs' / entry['file'], parse_dates=['timestamp']).set_index('timestamp')
        frame = frame.loc['2016-01-01':'2026-06-30']
        end = None
        if symbol in protocol['lifecycle']:
            end = pd.Timestamp(protocol['lifecycle'][symbol]['margin_cutoff']).tz_convert(None).normalize() - pd.Timedelta(days=1)
            frame = frame.loc[:end]
        if name == 'missing_one_percent':
            drop = rng.random(len(frame)) < .01
            if end is not None:
                drop &= frame.index != end
            drop[0] = drop[-1] = False
            frame = frame.loc[~drop]
        elif name == 'market_outage_7d':
            frame = frame.loc[~((frame.index >= '2023-12-23') & (frame.index <= '2023-12-29'))]
        available[symbol] = set(frame.index)
    tr = csv(name, 'trades.csv')
    violations = []
    same_or_prior = []
    for row in tr.itertuples():
        at = pd.Timestamp(row.fill_time)
        if at not in available[row.symbol]:
            violations.append({'symbol': row.symbol, 'fill_time': str(at), 'exit_reason': row.exit_reason})
        if row.exit_reason == 'signal' and at <= pd.Timestamp(row.signal_time):
            same_or_prior.append({'symbol': row.symbol, 'fill_time': str(at), 'signal_time': row.signal_time})
    curve = csv(name, 'equity_engine.csv')
    checks[name] = {'fills_without_real_bar': violations, 'entry_fill_not_after_signal': same_or_prior,
                    'finite_equity': bool(np.isfinite(curve.equity).all()),
                    'unique_close_event_ids': bool(not csv(name, 'close_events.csv').close_event_id.duplicated().any())}
economic_checks = {}
fields = ['signal_time', 'fill_time', 'symbol', 'side', 'qty', 'fill_price', 'commission', 'exit_reason']
for name, cutoff in [('prefix_2023', '2023-12-21'), ('prefix_2024', '2024-01-06'), ('reversed_symbols', None)]:
    short = csv(name, 'trades.csv')
    terminal_rows = short[short.exit_reason == 'EndOfBacktest']
    short = short[short.exit_reason != 'EndOfBacktest'][fields].copy()
    long = trades[trades.exit_reason != 'EndOfBacktest'][fields].copy()
    if cutoff:
        long = long[pd.to_datetime(long.fill_time) <= cutoff]
    for frame in (short, long):
        for col in ('signal_time', 'fill_time'):
            frame[col] = frame[col].map(lambda value: pd.Timestamp(value).value)
    sequential = short.reset_index(drop=True).equals(long.reset_index(drop=True))
    economic_checks[name] = {'equal_after_timestamp_normalization_in_same_order': sequential,
        'equal_economic_trade_multiset': short.sort_values(fields).reset_index(drop=True).equals(long.sort_values(fields).reset_index(drop=True)),
        'terminal_valuation_rows_excluded': len(terminal_rows),
        'note': 'Original raw comparison failures retained in completion.json; exact numeric values compared, no rounding tolerance.'}
outage_curve = csv('market_outage_7d', 'equity_requested_period.csv')
outage_rows = outage_curve[(outage_curve.timestamp >= '2023-12-23') & (outage_curve.timestamp <= '2023-12-29')]
save = {'restoration_cohorts': restoration.astype(object).where(restoration.notna(), None).to_dict('records'),
    'restoration_cohort_count': len(restoration), 'restoration_cohort_net_pnl': float(restoration.net_pnl.sum()),
    'restoration_total_r': float(restoration.r.sum()),
    'restoration_drawdown_pct': float((1 - restoration_equity / peak) * 100),
    'restoration_remaining_loss_to_liquidation': float(restoration_equity - peak * .8),
    'new_initial_risk_next_four_days': float(new_risks.actual_total_risk.sum()),
    'incremental_commission': float(late.commission.sum()),
    'incremental_slippage': float(sum(c['slippage'] for c in costs)),
    'incremental_impact': float(sum(c['impact'] for c in costs)),
    'financing_ledger_rows_by_scenario': counts,
    'rolling': {'count': len(ret), 'positive': int((ret > 0).sum()), 'negative': int((ret < 0).sum()),
                'median_return_pct': float(np.median(ret)), 'mean_return_pct': float(ret.mean()),
                'minimum_return_pct': float(ret.min()), 'maximum_return_pct': float(ret.max()),
                'interpretation': 'Independent capital and strategy state, not a tradable stitched equity curve.'},
    'data_execution_checks': checks, 'economic_invariance': economic_checks,
    'outage_calendar_rows': outage_rows.to_dict('records'),
    'outage_phase_explicitly_marked': bool((outage_rows.phase == 'data_outage').all())}
(root / 'deep_diagnostics.json').write_text(json.dumps(save, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
equity.loc['2023-12-20':'2024-01-07'].to_csv(root / 'restoration_equity_and_exposure.csv')
new_risks.to_csv(root / 'restoration_new_risk.csv', index=False)
print(json.dumps(save, ensure_ascii=False, indent=2))
