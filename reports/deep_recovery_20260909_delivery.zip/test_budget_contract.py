"""Adversarial contract: post-fill checks must preserve the reduced entry budget."""
from core.risk import RiskManager
from core.risk.circuit_breaker import BreakerAction
from core.protective_stops import EntryRiskPolicy, evaluate_fill_risk


def test_reduced_entry_budget_is_preserved_after_gap_fill():
    risk = RiskManager(risk_per_trade=.02, reduced_risk_multiplier=.5)
    risk.portfolio_breaker_action = BreakerAction.REDUCE
    quantity = risk.calculate_position_size(10000, 100, 90)
    reserved_risk = quantity * (100 - 90)
    assert reserved_risk == 100
    # Exact arguments used by BacktestEngine._reconcile_entry_risk:
    # base risk and health multiplier are passed; the account multiplier is lost.
    assessment = evaluate_fill_risk(
        symbol='BTC/USDT', lot_id='test-lot', side='long',
        fill_price=105, protective_stop=90, filled_qty=quantity,
        equity_at_fill=10000, base_risk_per_trade=risk.risk_per_trade,
        health_risk_multiplier=1, policy=EntryRiskPolicy(tolerance=.1),
    )
    assert assessment.actual_total_risk == 150
    assert assessment.breached and assessment.action == 'resize', assessment.to_dict()
